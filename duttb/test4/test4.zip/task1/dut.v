`timescale 1ns/1ps

module dut (
    input  wire clk,
    input  wire reset,
    input  wire we,             
    input  wire [31:0] wd,
    input  wire [4:0] rs1,
    input  wire [4:0] rs2,
    output wire [31:0] rdata1,
    output wire [31:0] rdata2
);

    reg_file i_reg_file (
        .clk(clk),
        .reset(reset),
        .we(we),
        .wd(wd),
        .rs1(rs1),
        .rs2(rs2),
        .rdata1(rdata1),
        .rdata2(rdata2)
    );

endmodule
