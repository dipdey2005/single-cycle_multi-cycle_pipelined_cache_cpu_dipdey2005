`timescale 1ns/1ps

module tb_reg_read;
reg clk;
reg reset;
reg we;
reg [31:0] wd;
reg [4:0] rs1;
reg [4:0] rs2;
reg [31:0] rdata1;
reg [31:0] rdata2;    

dut dut(
    .clk(clk),
    .reset(reset),
    .we(we),
    .wd(wd),
    .rs1(rs1),
    .rs2(rs2),
    .rdata1(rdata1),
    .rdata2(rdata2)
    );

always #5 clk = ~clk;

// ---------------------------------------------------------
    // Waveform dump configuration
    // ---------------------------------------------------------
    // This string will store the VCD file name passed from the command line.
    string vcd_file;

    // This initial block runs once at the start of simulation.
    initial begin
      // Check if a VCD file name was passed using +vcd=<filename>
      if ($value$plusargs("vcd=%s", vcd_file))
        // If provided, dump waveforms to that file
        $dumpfile(vcd_file);
      else
        // Otherwise, use a default file name
        $dumpfile("fa.vcd");

      // Dump all signals inside the DUT hierarchy
      $dumpvars(0, dut);
    end

    initial begin
        clk =1;
        reset =1;
        we =0;
        rs1 =0;
        rs2 =0;
        wd =0;

        #10;
        reset =0;
        we = 1;
        wd = 32'hA5A5A5A5;

        #10;
        reset=1;
        
        we = 0;
        rs1 = 5'd1;
        rs2 = 5'd1;

        #20;
        $finish;
    end
endmodule